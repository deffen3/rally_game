use amethyst::core::{Transform, SystemDesc};
use amethyst::derive::SystemDesc;
use amethyst::ecs::{Join, Read, ReadStorage, System, SystemData, World, WriteStorage};
use amethyst::input::{InputHandler};


use crate::rally::{Vehicle, ARENA_HEIGHT, ARENA_WIDTH, ActionBinding, MovementBindingTypes};

#[derive(SystemDesc)]
pub struct VehicleWeaponsSystem;

impl<'s> System<'s> for VehicleWeaponsSystem {
    type SystemData = (
        WriteStorage<'s, Transform>,
        WriteStorage<'s, Vehicle>,
        Read<'s, InputHandler<MovementBindingTypes>>,
    );

    fn run(&mut self, (mut transforms, vehicles, input): Self::SystemData) {
        for (vehicle, transform) in (&vehicles, &mut transforms).join() {
            let vehicle_weapon_fire = input.action_is_down(&ActionBinding::VehicleShoot(vehicle.id));
            
            if let Some(weapon_fire) = vehicle_weapon_fire {
                if weapon_fire == true {
                    println!("Fire Weapons!");
                }
            }
        }
    }
}